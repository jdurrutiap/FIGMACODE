import { createContext, useContext, useEffect, useRef, useState } from 'react'

type View = 'login' | 'student' | 'librarian' | 'admin' | 'reset'
type BookStatus = 'Disponible' | 'Reservado' | 'Prestado'
type Toast = { title: string; text: string } | null
type Book = (typeof initialBooks)[number] & { description?: string; enabled?: boolean }
type User = (typeof initialUsers)[number] & { passwordHash?: string; salt?: string; restricted?: boolean }
type Loan = { id: string; bookId: number; rut: string; start: string; due: string; returned: string | null; status: 'Reservado' | 'Prestado' | 'Devuelto' }
type Database = { books: Book[]; users: User[]; loans: Loan[] }
const STORAGE_KEY = 'inacap-library-demo-v3'
const isoNow = () => new Date().toISOString()
const dueDate = () => new Date(Date.now() + 14 * 86400000).toISOString()
const displayDate = (value: string | null) => value ? new Date(value).toLocaleString('es-CL') : '—'
const normalizeRut = (rut: string) => rut.replace(/[.\s]/g, '').toUpperCase()
const lateDays = (loan: Loan) => loan.status === 'Reservado' ? 0 : Math.max(0, Math.ceil(((loan.returned ? new Date(loan.returned).getTime() : Date.now()) - new Date(loan.due).getTime()) / 86400000))
const money = (value: number) => value.toLocaleString('es-CL', { style: 'currency', currency: 'CLP' })
async function credentialHash(password: string, salt: string) {
  const material = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveBits'])
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', salt: new TextEncoder().encode(salt), iterations: 100000, hash: 'SHA-256' }, material, 256)
  return Array.from(new Uint8Array(bits), byte => byte.toString(16).padStart(2, '0')).join('')
}
const LibraryContext = createContext<{
  db: Database; update: (fn: (data: Database) => Database) => void
  current: User; selectUser: (rut: string) => void
}> (null!)
const useLibrary = () => useContext(LibraryContext)

const Icon = ({ name, size = 18 }: { name: string; size?: number }) => {
  const paths: Record<string, React.ReactNode> = {
    book: <><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" /><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2Z" /></>,
    search: <><circle cx="11" cy="11" r="8" /><path d="m21 21-4.3-4.3" /></>,
    user: <><circle cx="12" cy="8" r="4" /><path d="M4 21a8 8 0 0 1 16 0" /></>,
    lock: <><rect width="16" height="12" x="4" y="10" rx="2" /><path d="M8 10V7a4 4 0 0 1 8 0v3" /></>,
    eye: <><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z" /><circle cx="12" cy="12" r="3" /></>,
    arrow: <><path d="m9 18 6-6-6-6" /></>,
    calendar: <><rect x="3" y="5" width="18" height="16" rx="2" /><path d="M16 3v4M8 3v4M3 11h18" /></>,
    history: <><path d="M3 12a9 9 0 1 0 3-6.7L3 8" /><path d="M3 3v5h5M12 7v5l3 2" /></>,
    users: <><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M22 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8" /></>,
    chart: <><path d="M3 3v18h18" /><path d="m7 16 4-5 4 3 5-7" /></>,
    grid: <><rect x="3" y="3" width="7" height="7" rx="1" /><rect x="14" y="3" width="7" height="7" rx="1" /><rect x="3" y="14" width="7" height="7" rx="1" /><rect x="14" y="14" width="7" height="7" rx="1" /></>,
    logout: <><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" /><path d="m16 17 5-5-5-5M21 12H9" /></>,
    bell: <><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M13.7 21h-3.4" /></>,
    filter: <path d="M4 4h16l-6 7v6l-4 2v-8Z" />,
    plus: <path d="M12 5v14M5 12h14" />,
    edit: <><path d="M12 20h9" /><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L8 18l-4 1 1-4Z" /></>,
    download: <><path d="M12 3v12m0 0 4-4m-4 4-4-4" /><path d="M4 19h16" /></>,
    shield: <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z" />,
    alert: <><path d="M10.3 3.3 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.3a2 2 0 0 0-3.4 0Z" /><path d="M12 9v4M12 17h.01" /></>,
    close: <path d="m6 6 12 12M18 6 6 18" />,
  }
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name]}</svg>
}

const initialBooks = [
  { id: 1, title: 'Cien años de soledad', author: 'Gabriel García Márquez', genre: 'Novela', editorial: 'Sudamericana', year: '1967', status: 'Disponible' as BookStatus, code: 'NOV-001', color: '#7b263d' },
  { id: 2, title: 'Clean Code', author: 'Robert C. Martin', genre: 'Tecnología', editorial: 'Prentice Hall', year: '2008', status: 'Disponible' as BookStatus, code: 'TEC-124', color: '#203247' },
  { id: 3, title: 'El principito', author: 'Antoine de Saint-Exupéry', genre: 'Literatura', editorial: 'Salamandra', year: '1943', status: 'Prestado' as BookStatus, code: 'LIT-043', color: '#37687b' },
  { id: 4, title: 'Diseño de interfaces', author: 'Jenifer Tidwell', genre: 'Diseño', editorial: 'O’Reilly', year: '2020', status: 'Reservado' as BookStatus, code: 'DIS-231', color: '#b76743' },
  { id: 5, title: 'Fundamentos de marketing', author: 'Philip Kotler', genre: 'Negocios', editorial: 'Pearson', year: '2019', status: 'Disponible' as BookStatus, code: 'NEG-088', color: '#534b74' },
  { id: 6, title: 'Historia de Chile', author: 'Sergio Villalobos', genre: 'Historia', editorial: 'Universitaria', year: '2016', status: 'Disponible' as BookStatus, code: 'HIS-032', color: '#5f6c54' },
]

const initialUsers = [
  { rut: '20.123.456-7', name: 'Sofía Valdés Soto', email: 'sofia.valdes@inacapmail.cl', role: 'Estudiante', location: 'Santiago, Chile', access: 'Hoy, 09:42', enabled: true },
  { rut: '15.884.210-3', name: 'Carlos Muñoz Vera', email: 'carlos.munoz@inacap.cl', role: 'Bibliotecario', location: 'Maipú, Chile', access: 'Hoy, 08:15', enabled: true },
  { rut: '12.456.789-5', name: 'Andrea Rojas Silva', email: 'andrea.rojas@inacap.cl', role: 'Administrador', location: 'Santiago, Chile', access: 'Ayer, 17:50', enabled: true },
  { rut: '21.092.334-1', name: 'Martín Lagos Díaz', email: 'martin.lagos@inacapmail.cl', role: 'Estudiante', location: 'Renca, Chile', access: '12 Jun, 11:23', enabled: false },
]

function Logo({ compact = false }: { compact?: boolean }) {
  return <div className="logo"><span className="logo-mark"><i /><i /><i /></span>{!compact && <span><b>INACAP</b><small>BIBLIOTECA DIGITAL</small></span>}</div>
}

function Button({ children, onClick, variant = 'primary', disabled = false, icon }: { children: React.ReactNode; onClick?: () => void; variant?: 'primary' | 'secondary' | 'ghost' | 'danger'; disabled?: boolean; icon?: string }) {
  return <button className={`btn btn-${variant}`} onClick={onClick} disabled={disabled}>{icon && <Icon name={icon} size={17} />}{children}</button>
}

function ToastMessage({ toast, close }: { toast: Toast; close: () => void }) {
  if (!toast) return null
  return <div className="toast"><span className="toast-check">✓</span><div><b>{toast.title}</b><p>{toast.text}</p></div><button onClick={close}><Icon name="close" size={16} /></button></div>
}

function DemoNav({ view, setView }: { view: View; setView: (v: View) => void }) {
  const items: { key: View; label: string }[] = [{ key: 'login', label: 'Login' }, { key: 'student', label: 'Estudiante' }, { key: 'librarian', label: 'Bibliotecario' }, { key: 'admin', label: 'Administrador' }, { key: 'reset', label: 'Restablecer clave' }]
  return <div className="demo-nav"><span><Icon name="grid" size={15} /> VISTA DEMO</span>{items.map(i => <button key={i.key} className={view === i.key ? 'active' : ''} onClick={() => setView(i.key)}>{i.label}</button>)}</div>
}

function Login({ go }: { go: (v: View) => void }) {
  const { db, update, selectUser } = useLibrary()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [show, setShow] = useState(false)
  const [attempts, setAttempts] = useState(0)
  const [error, setError] = useState('')
  const account = db.users.find(u => u.email.toLowerCase() === email.trim().toLowerCase())
  const detected = account?.role
  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (attempts >= 3) return
    if (!email || !password) return setError('Ingresa tu correo institucional y contraseña.')
    if (account && !account.enabled) return setError('Este usuario está inhabilitado. Solicita su habilitación al administrador.')
    const matches = account && (account.passwordHash ? await credentialHash(password, account.salt!) === account.passwordHash : password === 'Demo#2025')
    if (!matches || !account) {
      const next = attempts + 1; setAttempts(next)
      return setError(next >= 3 ? 'Cuenta bloqueada temporalmente por 15 minutos. Contacta a soporte si no reconoces estos intentos.' : `Contraseña incorrecta. Te quedan ${3 - next} intentos.`)
    }
    selectUser(account.rut)
    update(data => ({ ...data, users: data.users.map(u => u.rut === account.rut ? { ...u, access: new Date().toLocaleString('es-CL') } : u) }))
    go(account.role === 'Estudiante' ? 'student' : account.role === 'Administrador' ? 'admin' : 'librarian')
  }
  const useDemoProfile = (role: 'Estudiante' | 'Bibliotecario' | 'Administrador') => {
    const accounts = {
      Estudiante: 'sofia.valdes@inacapmail.cl',
      Bibliotecario: 'carlos.munoz@inacap.cl',
      Administrador: 'andrea.rojas@inacap.cl',
    }
    setEmail(accounts[role])
    setPassword('Demo#2025')
    setAttempts(0)
    setError('')
  }
  return <main className="auth-page">
    <section className="auth-visual">
      <div className="visual-overlay" />
      <div className="auth-brand"><Logo /><div><span className="eyebrow light">BIBLIOTECA DIGITAL INACAP</span><h1>Conocimiento que<br />transforma tu futuro.</h1><p>Accede a recursos académicos, reserva libros y gestiona tus préstamos desde un solo lugar.</p></div><small>© 2025 INACAP · Sistema de Gestión Bibliotecaria</small></div>
    </section>
    <section className="auth-form">
      <div className="mobile-logo"><Logo /></div>
      <div className="login-card">
        <span className="eyebrow">ACCESO SEGURO</span><h2>Bienvenido</h2><p className="muted">Ingresa con tus credenciales institucionales</p>
        {attempts >= 3 && <div className="inline-alert"><Icon name="lock" /><div><b>Acceso temporalmente bloqueado</b><span>Podrás intentar nuevamente en 14:59 minutos.</span></div></div>}
        <form onSubmit={submit}>
          <label>Correo institucional</label><div className="input-icon"><Icon name="user" /><input value={email} onChange={e => { setEmail(e.target.value); setError('') }} placeholder="nombre@inacapmail.cl" type="email" /><span className="role-detect">{detected || 'Rol automático'}</span></div>
          <label>Contraseña</label><div className="input-icon"><Icon name="lock" /><input value={password} onChange={e => { setPassword(e.target.value); setError('') }} placeholder="Ingresa tu contraseña" type={show ? 'text' : 'password'} /><button type="button" onClick={() => setShow(!show)}><Icon name="eye" /></button></div>
          {error && <p className="form-error"><Icon name="alert" size={15} />{error}</p>}
          <div className="form-row"><label className="check"><input type="checkbox" /> Recordarme</label><button type="button" className="text-link" onClick={() => go('reset')}>¿Olvidaste tu contraseña?</button></div>
          <button className="login-submit" disabled={attempts >= 3}>Iniciar sesión <Icon name="arrow" /></button>
        </form>
        <div className="demo-credentials"><Icon name="shield" /><div><b>Acceso rápido por perfil</b><span>Selecciona un rol para cargar credenciales seguras:</span><div className="demo-profiles"><button onClick={() => useDemoProfile('Estudiante')}>Estudiante</button><button onClick={() => useDemoProfile('Bibliotecario')}>Bibliotecario</button><button onClick={() => useDemoProfile('Administrador')}>Administrador</button></div><small>Contraseña demo: <code>Demo#2025</code></small></div></div>
        <section aria-label="Protección de datos: indicadores simulados" className="mt-3 rounded-lg border border-emerald-200 bg-emerald-50 p-3">
          <div className="flex items-center justify-between gap-2 text-xs font-bold text-emerald-800">
            <span className="flex items-center gap-2"><Icon name="lock" size={16} /> PROTECCIÓN DE DATOS ACTIVA</span>
            <span className="rounded-full bg-emerald-100 px-2 py-1">SEGURO</span>
          </div>
          <div className="mt-3 grid grid-cols-3 gap-2">
            {[
              ['TLS 1.3', 'Cifrado en tránsito'],
              ['AES-256', 'Cifrado en reposo'],
              ['Argon2id', 'Hash de contraseñas'],
            ].map(([title, description]) => <div key={title} className="min-w-0 rounded-md border border-emerald-200 bg-white p-2">
              <b className="block break-words text-sm text-emerald-950">{title}</b>
              <span className="mt-1 block text-sm leading-snug text-slate-600">{description}</span>
            </div>)}
          </div>
          <p className="mt-3 mb-0 text-sm leading-relaxed text-slate-600">Las credenciales nunca se almacenan en texto plano. Indicadores simulados para este prototipo.</p>
        </section>
        <p className="support">¿Problemas para ingresar? <b>Contacta a Soporte TI</b></p>
      </div>
    </section>
  </main>
}

const passwordRules = (password: string, name = '', rut = '') => [
  { label: 'Mínimo 8 caracteres', ok: password.length >= 8 },
  { label: 'Mayúsculas y minúsculas', ok: /[A-Z]/.test(password) && /[a-z]/.test(password) },
  { label: 'Letras y números', ok: /[A-Za-z]/.test(password) && /\d/.test(password) },
  { label: 'Al menos un carácter especial (@, #, /, ...)', ok: /[^A-Za-z0-9]/.test(password) },
  { label: 'Sin patrones inseguros o datos personales', ok: !!password && !/(1234|qwerty|abcd|password)/i.test(password) && !name.split(' ').filter(x => x.length > 3).some(x => password.toLowerCase().includes(x.toLowerCase())) && (!rut || !password.includes(rut.replace(/\D/g, '').slice(0, 5))) },
  { label: 'No coincide con tus últimas 3 contraseñas', ok: !!password && !['Inacap#2024', 'Biblioteca#1', 'Clave#2023'].includes(password) },
]

function PasswordChecklist({ password, name, rut }: { password: string; name?: string; rut?: string }) {
  return <div className="password-checklist">{passwordRules(password, name, rut).map(rule => <div className={rule.ok ? 'ok' : password ? 'bad' : ''} key={rule.label}><span>{rule.ok ? '✓' : '×'}</span>{rule.label}</div>)}</div>
}

function ResetPassword({ go, toast }: { go: (v: View) => void; toast: (t: Toast) => void }) {
  const { db, update } = useLibrary()
  const [step, setStep] = useState(1)
  const [email, setEmail] = useState('sofia.valdes@inacapmail.cl')
  const [password, setPassword] = useState('')
  const [confirm, setConfirm] = useState('')
  const user = db.users.find(u => u.email.toLowerCase() === email.trim().toLowerCase())
  const valid = !!user && passwordRules(password, user.name, user.rut).every(x => x.ok) && password === confirm
  const savePassword = async () => {
    if (!valid || !user) return
    const salt = crypto.randomUUID()
    const passwordHash = await credentialHash(password, salt)
    update(data => ({ ...data, users: data.users.map(u => u.rut === user.rut ? { ...u, salt, passwordHash } : u) }))
    setStep(3)
    toast({ title: 'Contraseña actualizada localmente', text: 'Puedes iniciar sesión con la nueva clave. No se envió un correo real.' })
  }
  return <main className="reset-page"><div className="reset-top"><Logo /><button onClick={() => go('login')} className="text-link">Volver al inicio de sesión</button></div><section className="reset-card">
    <div className="reset-icon"><Icon name="lock" size={26} /></div><span className="eyebrow">SEGURIDAD DE CUENTA</span><h2>{step === 1 ? 'Restablecer contraseña' : step === 2 ? 'Crea una nueva contraseña' : 'Contraseña actualizada'}</h2>
    {step === 1 && <><p className="muted">Restablecimiento local para la demo: no se envían correos ni se verifica tu identidad en un servidor.</p><label>Correo institucional</label><div className="input-icon"><Icon name="user" /><input value={email} onChange={e => setEmail(e.target.value)} /></div>{!user && <p className="form-error">No existe un usuario con este correo.</p>}<Button disabled={!user} onClick={() => setStep(2)}>Continuar en modo demo</Button></>}
    {step === 2 && <><div className="expiry-alert"><Icon name="alert" /><span><b>Actualización periódica requerida · Simulación</b>Renueva tu contraseña cada 90 días.</span></div><label>Nueva contraseña</label><div className="input-icon"><Icon name="lock" /><input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Escribe una clave segura" /></div><PasswordChecklist password={password} name={user?.name} rut={user?.rut} /><label>Confirmar contraseña</label><div className="input-icon"><Icon name="lock" /><input type="password" value={confirm} onChange={e => setConfirm(e.target.value)} /></div>{confirm && password !== confirm && <p className="form-error">Las contraseñas no coinciden.</p>}<Button disabled={!valid} onClick={() => { void savePassword() }}>Actualizar contraseña</Button></>}
    {step === 3 && <><div className="success-big">✓</div><p className="muted">Tu contraseña se actualizó correctamente. Ya puedes ingresar de forma segura.</p><Button onClick={() => go('login')}>Ir a iniciar sesión</Button></>}
    <div className="security-note"><Icon name="shield" /><span><b>Protegemos tu información</b>Nunca te pediremos tu contraseña por correo o teléfono.</span></div>
  </section></main>
}

function AppShell({ role, name, active, onActive, logout, children, actions }: { role: string; name: string; active: string; onActive: (s: string) => void; logout: () => void; children: React.ReactNode; actions?: React.ReactNode }) {
  const { current } = useLibrary()
  name = current.role === role ? current.name : name
  const nav = role === 'Estudiante' ? [['catalog', 'book', 'Catálogo'], ['history', 'history', 'Mis préstamos']] : role === 'Bibliotecario' ? [['loans', 'book', 'Préstamos'], ['late', 'alert', 'Moras y restricciones'], ['general', 'history', 'Historial general']] : [['dashboard', 'chart', 'Dashboard'], ['users', 'users', 'Usuarios y roles'], ['books', 'book', 'Catálogo']]
  return <div className="app-shell"><header><Logo /><nav>{nav.map(n => <button className={active === n[0] ? 'active' : ''} key={n[0]} onClick={() => onActive(n[0])}><Icon name={n[1]} />{n[2]}</button>)}</nav><div className="header-actions">{actions}<button className="bell"><Icon name="bell" /><i /></button><div className="user-chip"><span>{name.split(' ').map(x => x[0]).slice(0, 2).join('')}</span><div><b>{name}</b><small>{role}</small></div></div><button className="logout" onClick={logout} title="Cerrar sesión"><Icon name="logout" /></button></div></header>{children}</div>
}

function Status({ status }: { status: string }) { return <span className={`status ${status.toLowerCase().split(' ').join('-')}`}><i />{status}</span> }

function Student({ logout, notify }: { logout: () => void; notify: (t: Toast) => void }) {
  const { db, update, current } = useLibrary()
  const student = current.role === 'Estudiante' ? current : db.users[0]
  const [active, setActive] = useState('catalog')
  const restricted = !!student.restricted
  const setRestricted = (value: boolean) => update(data => ({ ...data, users: data.users.map(u => u.rut === student.rut ? { ...u, restricted: value } : u) }))
  const books = db.books.filter(b => b.enabled !== false)
  const [query, setQuery] = useState('')
  const [genre, setGenre] = useState('Todos')
  const [reserve, setReserve] = useState<Book | null>(null)
  const filtered = books.filter(b => (b.title + b.author).toLowerCase().includes(query.toLowerCase()) && (genre === 'Todos' || b.genre === genre))
  const confirmReserve = () => {
    if (!reserve || restricted || !student.enabled) return
    update(data => {
      const book = data.books.find(b => b.id === reserve.id)
      if (!book || book.enabled === false || book.status !== 'Disponible') return data
      return { ...data, books: data.books.map(b => b.id === book.id ? { ...b, status: 'Reservado' } : b), loans: [{ id: crypto.randomUUID(), bookId: book.id, rut: student.rut, start: isoNow(), due: dueDate(), returned: null, status: 'Reservado' }, ...data.loans] }
    })
    setReserve(null)
    notify({ title: 'Reserva confirmada', text: 'Registro visible para el bibliotecario. Correo de respaldo simulado.' })
  }
  return <AppShell role="Estudiante" name="Sofía Valdés" active={active} onActive={setActive} logout={logout} actions={<button className="restriction-toggle" onClick={() => setRestricted(!restricted)}><i className={restricted ? 'on' : ''} /> Demo restricción</button>}>
    {restricted && <div className="restriction-banner"><Icon name="alert" /><div><b>Tienes una restricción activa</b><span>Mora asociada a “El principito” · Finaliza el 28 Jun 2025 a las 18:00 h</span></div><small>Las reservas se encuentran deshabilitadas</small></div>}
    {active === 'catalog' ? <main className="content">
      <div className="page-heading"><div><span className="eyebrow">BIBLIOTECA DIGITAL</span><h1>Explora el catálogo</h1><p>Encuentra tu próxima lectura entre nuestros recursos académicos.</p></div><div className="availability"><span><b>{books.filter(b => b.status === 'Disponible').length}</b> disponibles ahora</span><Icon name="book" size={28} /></div></div>
      <div className="search-panel"><div className="search-large"><Icon name="search" /><input placeholder="Buscar por título, autor o palabra clave..." value={query} onChange={e => setQuery(e.target.value)} /></div><select value={genre} onChange={e => setGenre(e.target.value)}><option>Todos</option>{[...new Set(books.map(b => b.genre))].map(x => <option key={x}>{x}</option>)}</select><select><option>Todos los autores</option><option>Gabriel García Márquez</option><option>Robert C. Martin</option></select><select><option>Todas las editoriales</option><option>Pearson</option><option>Sudamericana</option></select><Button variant="secondary" icon="filter">Filtros</Button></div>
      <div className="results-head"><b>{filtered.length} libros encontrados</b><select><option>Más relevantes</option><option>Más recientes</option></select></div>
      <div className="book-grid">{filtered.map(book => <article className="book-card" key={book.id}><div className="book-cover" style={{ background: book.color }}><small>{book.genre.toUpperCase()}</small><strong>{book.title}</strong><span>{book.author}</span><i /></div><div className="book-info"><Status status={book.status} /><h3>{book.title}</h3><p>{book.author}</p><dl><div><dt>Género</dt><dd>{book.genre}</dd></div><div><dt>Editorial</dt><dd>{book.editorial}</dd></div><div><dt>Lanzamiento</dt><dd>{book.year}</dd></div></dl><Button disabled={book.status !== 'Disponible' || restricted} onClick={() => setReserve(book)}>{restricted ? 'Reserva bloqueada' : book.status === 'Disponible' ? 'Reservar libro' : 'No disponible'}</Button></div></article>)}</div>
    </main> : <StudentHistory />}
    {reserve && <Modal title="Confirmar reserva" close={() => setReserve(null)}><div className="reserve-summary"><div className="mini-cover" style={{ background: reserve.color }}><Icon name="book" /></div><div><b>{reserve.title}</b><span>{reserve.author}</span><small>{reserve.code} · {reserve.editorial}</small></div></div><div className="modal-notice"><Icon name="calendar" /><span><b>Retiro disponible por 48 horas</b>Acércate a la biblioteca de tu sede con tu credencial. Recibirás un correo de respaldo.</span></div><div className="modal-actions"><Button variant="secondary" onClick={() => setReserve(null)}>Cancelar</Button><Button onClick={confirmReserve}>Confirmar reserva</Button></div></Modal>}
  </AppShell>
}

function StudentHistory() {
  const { db, current } = useLibrary()
  const rut = current.role === 'Estudiante' ? current.rut : db.users[0].rut
  const loans = db.loans.filter(l => l.rut === rut)
  const rows = loans.map(l => [db.books.find(b => b.id === l.bookId)?.title || 'Libro archivado', displayDate(l.start), displayDate(l.due), displayDate(l.returned), l.status, money(lateDays(l) * 1000)])
  return <main className="content"><div className="page-heading"><div><span className="eyebrow">MI ACTIVIDAD</span><h1>Historial de préstamos</h1><p>Consulta tus préstamos activos, devoluciones y multas.</p></div><div className="kpi-inline"><b>{loans.length}</b><span>Registros en tu historial</span></div></div><div className="table-card"><DataTable headers={['Libro', 'Inicio', 'Entrega pactada', 'Devolución real', 'Estado', 'Multa']} rows={rows} statusIndex={4} /></div></main>
}

function DataTable({ headers, rows, statusIndex, actions }: { headers: string[]; rows: (string | React.ReactNode)[][]; statusIndex?: number; actions?: (i: number) => React.ReactNode }) {
  return <div className="table-wrap"><table><thead><tr>{headers.map(h => <th key={h}>{h}</th>)}{actions && <th>Acciones</th>}</tr></thead><tbody>{rows.map((r, i) => <tr key={i}>{r.map((c, j) => <td key={j}>{j === statusIndex && typeof c === 'string' ? <Status status={c} /> : c}</td>)}{actions && <td><div className="table-actions">{actions(i)}</div></td>}</tr>)}</tbody></table></div>
}

function Librarian({ logout, notify }: { logout: () => void; notify: (t: Toast) => void }) {
  const { db, update } = useLibrary()
  const [active, setActive] = useState('loans')
  const [query, setQuery] = useState('')
  const loans = db.loans.filter(l => l.status !== 'Devuelto').map(l => ({
    ...l, student: db.users.find(u => u.rut === l.rut)?.name || l.rut,
    book: db.books.find(b => b.id === l.bookId)?.title || 'Libro archivado',
  })).filter(l => `${l.student} ${l.rut} ${l.book}`.toLowerCase().includes(query.toLowerCase()))
  const action = (i: number) => {
    const loan = loans[i]
    const delivered = loan.status === 'Reservado'
    update(data => ({ ...data, books: data.books.map(b => b.id === loan.bookId ? { ...b, status: delivered ? 'Prestado' : 'Disponible' } : b), loans: data.loans.map(l => l.id === loan.id ? { ...l, status: delivered ? 'Prestado' : 'Devuelto', start: delivered ? isoNow() : l.start, due: delivered ? dueDate() : l.due, returned: delivered ? null : isoNow() } : l) }))
    notify({ title: delivered ? 'Entrega validada' : 'Devolución registrada', text: 'Catálogo, historial y estadísticas actualizados. Correo simulado.' })
  }
  return <AppShell role="Bibliotecario" name="Carlos Muñoz" active={active} onActive={setActive} logout={logout}>
    <main className="content">
      {active === 'loans' && <><div className="page-heading"><div><span className="eyebrow">OPERACIÓN BIBLIOTECARIA</span><h1>Gestión de préstamos</h1><p>Las reservas de estudiantes aparecen aquí automáticamente.</p></div></div><div className="stats-row"><MiniStat icon="book" value={String(db.loans.filter(l => l.status === 'Prestado').length)} label="Préstamos activos" tone="red" /><MiniStat icon="calendar" value={String(db.loans.filter(l => l.status === 'Reservado').length)} label="Reservas por retirar" /><MiniStat icon="history" value={String(db.loans.filter(l => l.returned?.slice(0, 10) === isoNow().slice(0, 10)).length)} label="Devoluciones hoy" /></div><div className="table-card"><div className="table-toolbar"><div className="search-small"><Icon name="search" /><input aria-label="Buscar préstamo" placeholder="Buscar por RUT o título..." value={query} onChange={e => setQuery(e.target.value)} /></div></div><DataTable headers={['Estudiante', 'RUT', 'Libro', 'Inicio', 'Entrega pactada', 'Estado']} rows={loans.map(l => [<b>{l.student}</b>, l.rut, l.book, displayDate(l.start), displayDate(l.due), l.status])} statusIndex={5} actions={i => <Button variant={loans[i].status === 'Reservado' ? 'primary' : 'secondary'} onClick={() => action(i)}>{loans[i].status === 'Reservado' ? 'Validar entrega' : 'Registrar devolución'}</Button>} /></div></>}
      {active === 'late' && <LateLoans notify={notify} />}
      {active === 'general' && <GeneralHistory />}
    </main>
  </AppShell>
}

function MiniStat({ icon, value, label, tone = '' }: { icon: string; value: string; label: string; tone?: string }) { return <div className="mini-stat"><span className={tone}><Icon name={icon} /></span><div><b>{value}</b><small>{label}</small></div></div> }

function LateLoans({ notify }: { notify: (t: Toast) => void }) {
  const { db, update } = useLibrary()
  const late = db.loans.filter(l => l.status === 'Prestado' && lateDays(l) > 0)
  return <><div className="page-heading"><div><span className="eyebrow">CONTROL DE MORA</span><h1>Moras y restricciones</h1><p>Multa automática: $1.000 por día. {late.length} préstamos atrasados.</p></div></div><div className="table-card"><DataTable headers={['Estudiante', 'RUT', 'Libro', 'Fecha pactada', 'Atraso', 'Multa']} rows={late.map(l => [db.users.find(u => u.rut === l.rut)?.name, l.rut, db.books.find(b => b.id === l.bookId)?.title, displayDate(l.due), `${lateDays(l)} días`, money(lateDays(l) * 1000)])} actions={i => { const user = db.users.find(u => u.rut === late[i].rut); return <Button variant="secondary" onClick={() => { update(data => ({ ...data, users: data.users.map(u => u.rut === late[i].rut ? { ...u, restricted: !u.restricted } : u) })); notify({ title: 'Restricción actualizada', text: 'El portal del estudiante refleja este cambio.' }) }}>{user?.restricted ? 'Retirar restricción' : 'Aplicar restricción'}</Button> }} /></div></>
}

function GeneralHistory() {
  const { db } = useLibrary()
  const [query, setQuery] = useState('')
  const rows = db.loans.map(l => [db.users.find(u => u.rut === l.rut)?.name || l.rut, db.books.find(b => b.id === l.bookId)?.title || 'Libro archivado', displayDate(l.start), displayDate(l.due), l.status]).filter(row => row.join(' ').toLowerCase().includes(query.toLowerCase()))
  return <><div className="page-heading"><div><span className="eyebrow">TRAZABILIDAD</span><h1>Historial general</h1><p>Movimientos persistidos en este navegador.</p></div></div><div className="table-card"><div className="table-toolbar"><div className="search-small"><Icon name="search" /><input aria-label="Buscar historial" placeholder="Estudiante o libro..." value={query} onChange={e => setQuery(e.target.value)} /></div></div><DataTable headers={['Estudiante', 'Libro', 'Inicio', 'Fecha pactada', 'Estado']} rows={rows} statusIndex={4} /></div></>
}

function Admin({ logout, notify }: { logout: () => void; notify: (t: Toast) => void }) {
  const [active, setActive] = useState('dashboard')
  const [userModal, setUserModal] = useState<User | 'new' | null>(null)
  const [bookModal, setBookModal] = useState<Book | 'new' | null>(null)
  return <AppShell role="Administrador" name="Andrea Rojas" active={active} onActive={setActive} logout={logout}>
    <main className="content">
      {active === 'dashboard' && <Dashboard notify={notify} />}
      {active === 'users' && <Users open={user => setUserModal(user || 'new')} />}
      {active === 'books' && <AdminBooks open={book => setBookModal(book || 'new')} notify={notify} />}
    </main>
    {userModal && <UserModal user={userModal === 'new' ? undefined : userModal} close={() => setUserModal(null)} notify={notify} />}
    {bookModal && <BookModal book={bookModal === 'new' ? undefined : bookModal} close={() => setBookModal(null)} notify={notify} />}
  </AppShell>
}

function Dashboard({ notify }: { notify: (t: Toast) => void }) {
  const { db } = useLibrary()
  const books = db.books.filter(b => b.enabled !== false)
  const available = books.filter(b => b.status === 'Disponible').length
  const active = db.loans.filter(l => l.status === 'Prestado').length
  const reservations = db.loans.filter(l => l.status === 'Reservado').length
  const overdue = new Set(db.loans.filter(l => l.status === 'Prestado' && lateDays(l) > 0).map(l => l.rut)).size
  const months = Array.from({ length: 6 }, (_, i) => {
    const date = new Date(); date.setDate(1); date.setMonth(date.getMonth() - 5 + i)
    return { label: date.toLocaleDateString('es-CL', { month: 'short' }), count: db.loans.filter(l => { const d = new Date(l.start); return d.getFullYear() === date.getFullYear() && d.getMonth() === date.getMonth() }).length }
  })
  const genres = [...new Set(db.books.map(b => b.genre))].map(genre => ({ genre, count: db.loans.filter(l => db.books.find(b => b.id === l.bookId)?.genre === genre).length })).filter(g => g.count > 0)
  const colors = ['#c8102e', '#25384f', '#a35d15', '#54744d', '#6b467d', '#475569']
  let offset = 0
  const gradient = genres.map((g, i) => { const from = offset; offset += g.count / Math.max(1, db.loans.length) * 100; return `${colors[i % colors.length]} ${from}% ${offset}%` }).join(',')
  const exportCsv = () => {
    const csv = '\uFEFFIndicador;Valor\n' + [['Libros habilitados', books.length], ['Disponibles', available], ['Préstamos activos', active], ['Reservas', reservations], ['Usuarios con mora', overdue]].map(r => r.join(';')).join('\n')
    const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }))
    const a = document.createElement('a'); a.href = url; a.download = 'reporte-inacap.csv'; a.click(); URL.revokeObjectURL(url)
    notify({ title: 'Reporte descargado', text: 'Archivo CSV compatible con Excel con los valores actuales.' })
  }
  return <><div className="page-heading"><div><span className="eyebrow">RESUMEN EJECUTIVO</span><h1>Dashboard</h1><p>Datos de demostración reales · {new Date().toLocaleString('es-CL')}</p></div><div className="export-group"><Button variant="secondary" icon="download" onClick={() => window.print()}>Imprimir / PDF</Button><Button variant="secondary" icon="download" onClick={exportCsv}>Exportar Excel (CSV)</Button></div></div>
    <div className="kpi-grid">{[
      ['book', 'Total de libros', books.length, `${available} disponibles ahora`],
      ['history', 'Préstamos activos', active, `${reservations} reservas pendientes`],
      ['alert', 'Usuarios con mora', overdue, 'Multa: $1.000 por día'],
      ['users', 'Usuarios habilitados', db.users.filter(u => u.enabled).length, `${db.users.length} usuarios registrados`],
    ].map(([icon, label, value, detail]) => <div className="kpi-card" key={String(label)}><span><Icon name={String(icon)} /></span><small>{label}</small><b>{value}</b><em>{detail}</em></div>)}</div>
    <div className="charts-grid"><div className="chart-card wide"><div className="chart-head"><div><b>Reservas y préstamos por mes</b><span>Últimos seis meses · {db.loans.length} registros</span></div></div><div className="bar-chart" role="img" aria-label={months.map(m => `${m.label}: ${m.count}`).join(', ')}>{months.map(m => <div key={m.label}><span style={{ height: `${m.count / Math.max(1, ...months.map(x => x.count)) * 85}%` }}><i>{m.count}</i></span><small>{m.label}</small></div>)}</div></div><div className="chart-card"><div className="chart-head"><div><b>Géneros más solicitados</b><span>Basado en reservas y préstamos</span></div></div><div className="donut" role="img" aria-label={genres.map(g => `${g.genre}: ${g.count}`).join(', ') || 'Sin préstamos'} style={{ background: gradient ? `conic-gradient(${gradient})` : '#e5e7eb' }}><div><b>{db.loans.length}</b><small>registros</small></div></div><ul className="legend">{genres.map((g, i) => <li key={g.genre}><i style={{ background: colors[i % colors.length] }} />{g.genre}<b>{Math.round(g.count / db.loans.length * 100)}%</b></li>)}</ul></div></div>
  </>
}

function Users({ open }: { open: (user?: User) => void }) {
  const { db, update } = useLibrary()
  const [query, setQuery] = useState('')
  const users = db.users.filter(u => `${u.name} ${u.email} ${u.rut} ${u.role}`.toLowerCase().includes(query.toLowerCase()))
  return <><div className="page-heading"><div><span className="eyebrow">ADMINISTRACIÓN</span><h1>Usuarios y roles</h1><p>{db.users.filter(u => u.enabled).length} habilitados · Los cambios afectan al login local.</p></div><Button icon="plus" onClick={() => open()}>Nuevo usuario</Button></div><div className="table-card"><div className="table-toolbar"><div className="search-small"><Icon name="search" /><input aria-label="Buscar usuarios" placeholder="Nombre, RUT, correo o rol..." value={query} onChange={e => setQuery(e.target.value)} /></div></div><DataTable headers={['Usuario', 'RUT', 'Correo', 'Rol', 'Comuna / País', 'Último acceso', 'Estado']} rows={users.map(u => [<b>{u.name}</b>, u.rut, u.email, u.role, u.location, u.access, u.enabled ? 'Habilitado' : 'Inhabilitado'])} statusIndex={6} actions={i => <><button aria-label={`Editar ${users[i].name}`} className="icon-btn" onClick={() => open(users[i])}><Icon name="edit" /></button><button aria-label={`Cambiar acceso de ${users[i].name}`} aria-pressed={users[i].enabled} className={`switch ${users[i].enabled ? 'on' : ''}`} onClick={() => update(data => ({ ...data, users: data.users.map(u => u.rut === users[i].rut ? { ...u, enabled: !u.enabled } : u) }))}><i /></button></>} /></div></>
}

function AdminBooks({ open, notify }: { open: (book?: Book) => void; notify: (t: Toast) => void }) {
  const { db, update } = useLibrary()
  const [query, setQuery] = useState('')
  const books = db.books.filter(b => `${b.title} ${b.author} ${b.code}`.toLowerCase().includes(query.toLowerCase()))
  const toggle = (book: Book) => {
    update(data => ({ ...data, books: data.books.map(b => b.id === book.id ? { ...b, enabled: b.enabled === false } : b) }))
    notify({ title: book.enabled === false ? 'Libro habilitado' : 'Libro retirado del catálogo', text: 'Borrado lógico local: el historial se conserva y puedes restaurarlo.' })
  }
  return <><div className="page-heading"><div><span className="eyebrow">ADMINISTRACIÓN</span><h1>Catálogo de libros</h1><p>Los cambios se reflejan automáticamente en el portal del estudiante.</p></div><Button icon="plus" onClick={() => open()}>Nuevo libro</Button></div><div className="table-card"><div className="table-toolbar"><div className="search-small"><Icon name="search" /><input aria-label="Buscar libros" placeholder="Título, autor o código..." value={query} onChange={e => setQuery(e.target.value)} /></div></div><DataTable headers={['Código', 'Título', 'Autor', 'Editorial', 'Género', 'Lanzamiento', 'Estado']} rows={books.map(b => [b.code, <b>{b.title}</b>, b.author, b.editorial, b.genre, b.year, b.enabled === false ? 'Inhabilitado' : b.status])} statusIndex={6} actions={i => <><button aria-label={`Editar ${books[i].title}`} className="icon-btn" onClick={() => open(books[i])}><Icon name="edit" /></button><button className="text-danger" onClick={() => toggle(books[i])}>{books[i].enabled === false ? 'Restaurar' : 'Eliminar / deshabilitar'}</button></>} /></div></>
}

function Modal({ title, close, children, wide = false }: { title: string; close: () => void; children: React.ReactNode; wide?: boolean }) {
  const ref = useRef<HTMLDivElement>(null)
  const closeRef = useRef(close)
  closeRef.current = close
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null
    const dialog = ref.current!
    const targets = () => Array.from(dialog.querySelectorAll<HTMLElement>('button:not(:disabled),input,select,textarea,[tabindex="0"]'))
    ;(targets()[0] || dialog).focus()
    const handle = (event: KeyboardEvent) => {
      if (event.key === 'Escape') closeRef.current()
      if (event.key !== 'Tab') return
      const items = targets(); const first = items[0]; const last = items[items.length - 1]
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus() }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus() }
    }
    dialog.addEventListener('keydown', handle)
    return () => { dialog.removeEventListener('keydown', handle); previous?.focus() }
  }, [])
  return <div className="modal-backdrop" onMouseDown={e => e.target === e.currentTarget && close()}><div ref={ref} role="dialog" aria-modal="true" aria-labelledby="modal-title" tabIndex={-1} className={`modal ${wide ? 'wide' : ''}`}><div className="modal-head"><div><span className="eyebrow">SISTEMA INACAP</span><h2 id="modal-title">{title}</h2></div><button aria-label="Cerrar diálogo" onClick={close}><Icon name="close" /></button></div>{children}</div></div>
}

function UserModal({ user, close, notify }: { user?: User; close: () => void; notify: (t: Toast) => void }) {
  const { db, update } = useLibrary()
  const [name, setName] = useState(user?.name || '')
  const [rut, setRut] = useState(user?.rut || '')
  const [email, setEmail] = useState(user?.email || '')
  const [role, setRole] = useState(user?.role || 'Estudiante')
  const [enabled, setEnabled] = useState(user?.enabled ?? true)
  const [location, setLocation] = useState(user?.location.split(',')[0] || 'Santiago')
  const [password, setPassword] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const rutValid = /^\d{1,2}\.\d{3}\.\d{3}-[\dkK]$/.test(rut)
  const normalizedEmail = email.trim().toLowerCase()
  const domainValid = new RegExp(`^[^\\s@]+@${role === 'Estudiante' ? 'inacapmail' : 'inacap'}\\.cl$`).test(normalizedEmail)
  const duplicate = db.users.some(u => u.rut !== user?.rut && (normalizeRut(u.rut) === normalizeRut(rut) || u.email.toLowerCase() === normalizedEmail))
  const valid = name.trim().length > 4 && rutValid && domainValid && !duplicate && (!!user && !password || passwordRules(password, name, rut).every(r => r.ok))
  const save = async () => {
    if (!valid || busy) return
    setBusy(true)
    try {
      const salt = password ? crypto.randomUUID() : user?.salt
      const passwordHash = password ? await credentialHash(password, salt!) : user?.passwordHash
      const saved: User = { ...user, name: name.trim(), rut, email: normalizedEmail, role, enabled, location: `${location}, Chile`, access: user?.access || 'Sin acceso', salt, passwordHash }
      update(data => ({ ...data, users: user ? data.users.map(u => u.rut === user.rut ? saved : u) : [...data.users, saved], loans: data.loans.map(l => l.rut === user?.rut ? { ...l, rut } : l) }))
      close(); notify({ title: user ? 'Usuario actualizado' : 'Usuario creado', text: 'El acceso y el rol ya están disponibles en el login local. No se envió correo real.' })
    } catch { setError('No se pudo guardar la credencial. Intenta nuevamente.'); setBusy(false) }
  }
  return <Modal title={user ? 'Editar usuario' : 'Crear nuevo usuario'} close={close} wide><div className="form-grid">
    <div><label htmlFor="user-name">Nombre completo</label><input id="user-name" value={name} onChange={e => setName(e.target.value)} placeholder="Daniela Pérez Soto" /></div>
    <div><label htmlFor="user-rut">RUT</label><input id="user-rut" value={rut} onChange={e => setRut(e.target.value)} placeholder="12.345.678-9" />{rut && !rutValid && <p className="text-sm text-red-700">Formato requerido: 12.345.678-9</p>}</div>
    <div><label htmlFor="user-role">Rol</label><select id="user-role" value={role} onChange={e => setRole(e.target.value)}><option>Estudiante</option><option>Bibliotecario</option><option>Administrador</option></select></div>
    <div><label htmlFor="user-email">Correo institucional</label><input id="user-email" value={email} onChange={e => setEmail(e.target.value)} placeholder={role === 'Estudiante' ? 'nombre@inacapmail.cl' : 'nombre@inacap.cl'} />{email && !domainValid && <p className="text-sm text-red-700">El dominio no corresponde al rol.</p>}</div>
    <div><label htmlFor="user-location">Comuna</label><select id="user-location" value={location} onChange={e => setLocation(e.target.value)}><option>Santiago</option><option>Maipú</option><option>Renca</option></select></div>
    <div><label>País</label><input aria-label="País" value="Chile" readOnly /></div>
    <div className="full"><label htmlFor="user-password">{user ? 'Nueva contraseña (opcional)' : 'Contraseña para login demo'}</label><input id="user-password" type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder={user ? 'Vacío para conservar la actual' : 'Crea una clave de demostración'} /><PasswordChecklist password={password} name={name} rut={rut} /></div>
    <div className="full switch-row"><div><b>Usuario habilitado</b><span>Inhabilitar aplica borrado lógico e impide iniciar sesión.</span></div><button aria-label="Usuario habilitado" aria-pressed={enabled} className={`switch ${enabled ? 'on' : ''}`} onClick={() => setEnabled(!enabled)}><i /></button></div>
  </div>{duplicate && <p className="text-sm text-red-700">El RUT o el correo ya existe.</p>}{error && <p role="alert">{error}</p>}<div className="modal-actions"><Button variant="secondary" onClick={close}>Cancelar</Button><Button disabled={!valid || busy} onClick={() => { void save() }}>{busy ? 'Guardando…' : user ? 'Guardar cambios' : 'Crear usuario'}</Button></div></Modal>
}

function BookModal({ book, close, notify }: { book?: Book; close: () => void; notify: (t: Toast) => void }) {
  const { db, update } = useLibrary()
  const [draft, setDraft] = useState<Book>(book || { id: Date.now(), title: '', author: '', editorial: '', genre: 'Tecnología', description: '', year: '', status: 'Disponible', color: '#203247', code: `LIB-${Date.now().toString().slice(-6)}`, enabled: true })
  const field = (key: keyof Book, value: string | boolean) => setDraft(d => ({ ...d, [key]: value }))
  const valid = [draft.title, draft.author, draft.editorial, draft.genre, draft.description || ''].every(value => value.trim().length > 0)
  const hasActiveLoan = db.loans.some(l => l.bookId === draft.id && l.status !== 'Devuelto')
  const save = () => {
    if (!valid) return
    update(data => {
      let loans = data.loans
      const existing = loans.find(l => l.bookId === draft.id && l.status !== 'Devuelto')
      if (draft.status === 'Disponible' && existing) loans = loans.map(l => l.id === existing.id ? { ...l, status: 'Devuelto', returned: isoNow() } : l)
      else if (existing) loans = loans.map(l => l.id === existing.id ? { ...l, status: draft.status as 'Reservado' | 'Prestado' } : l)
      else if (draft.status !== 'Disponible') loans = [{ id: crypto.randomUUID(), bookId: draft.id, rut: data.users.find(u => u.role === 'Estudiante')!.rut, status: draft.status, start: isoNow(), due: dueDate(), returned: null }, ...loans]
      return { ...data, books: book ? data.books.map(b => b.id === book.id ? draft : b) : [...data.books, draft], loans }
    })
    close(); notify({ title: book ? 'Libro actualizado' : 'Libro agregado', text: 'El catálogo del estudiante y el dashboard ya reflejan los cambios.' })
  }
  return <Modal title={book ? 'Editar libro' : 'Nuevo libro'} close={close} wide><div className="form-grid">
    {(['title', 'author', 'editorial', 'genre', 'year'] as const).map((key, index) => <div key={key} className={key === 'title' ? 'full' : ''}><label htmlFor={`book-${key}`}>{['Título', 'Autor', 'Editorial', 'Género', 'Lanzamiento (año o fecha)'][index]}</label><input id={`book-${key}`} value={draft[key]} onChange={e => field(key, e.target.value)} /></div>)}
    <div className="full"><label htmlFor="book-description">Descripción</label><textarea id="book-description" value={draft.description || ''} onChange={e => field('description', e.target.value)} /></div>
    <div><label htmlFor="book-status">Estado</label><select id="book-status" value={draft.status} onChange={e => field('status', e.target.value)}><option>Disponible</option><option>Reservado</option><option>Prestado</option></select></div>
    <div className="switch-row"><div><b>Ejemplar habilitado</b><span>Visible en el catálogo</span></div><button aria-label="Ejemplar habilitado" aria-pressed={draft.enabled !== false} className={`switch ${draft.enabled !== false ? 'on' : ''}`} onClick={() => field('enabled', draft.enabled === false)}><i /></button></div>
  </div><p className="mt-4 text-sm text-slate-600">{hasActiveLoan ? 'Cambiar a Disponible registra la devolución del préstamo activo.' : 'Un estado Reservado o Prestado crea un registro demo asociado al primer estudiante.'}</p><div className="modal-actions"><Button variant="secondary" onClick={close}>Cancelar</Button><Button disabled={!valid} onClick={save}>Guardar libro</Button></div></Modal>
}

export default function App() {
  const [db, setDb] = useState<Database>(() => {
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null')
      if (saved && Array.isArray(saved.books) && Array.isArray(saved.users) && saved.users.length && Array.isArray(saved.loans)) return saved
    } catch { /* La demo funciona en memoria si el almacenamiento no está disponible. */ }
    return { books: initialBooks.map(b => ({ ...b, enabled: true, description: `Recurso académico: ${b.title}.` })), users: initialUsers, loans: [
      { id: 'seed-loan-3', bookId: 3, rut: initialUsers[3].rut, start: new Date(Date.now() - 20 * 86400000).toISOString(), due: new Date(Date.now() - 6 * 86400000).toISOString(), returned: null, status: 'Prestado' },
      { id: 'seed-loan-4', bookId: 4, rut: initialUsers[0].rut, start: isoNow(), due: dueDate(), returned: null, status: 'Reservado' },
    ] }
  })
  const [storageError, setStorageError] = useState(false)
  const dbRef = useRef(db)
  const update = (fn: (data: Database) => Database) => {
    const next = fn(dbRef.current)
    dbRef.current = next
    setDb(next)
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(next)); setStorageError(false) }
    catch { setStorageError(true) }
  }
  useEffect(() => {
    const sync = (event: StorageEvent) => {
      if (event.key !== STORAGE_KEY || !event.newValue) return
      try {
        const next = JSON.parse(event.newValue)
        if (Array.isArray(next.books) && Array.isArray(next.users) && next.users.length && Array.isArray(next.loans)) { dbRef.current = next; setDb(next) }
      } catch { /* Se ignoran datos externos inválidos. */ }
    }
    window.addEventListener('storage', sync)
    return () => window.removeEventListener('storage', sync)
  }, [])
  const [currentRut, selectUser] = useState(initialUsers[0].rut)
  const current = db.users.find(u => u.rut === currentRut) || db.users[0]
  const [view, setView] = useState<View>('login')
  const [toast, setToast] = useState<Toast>(null)
  const notify = (t: Toast) => { setToast(t); window.setTimeout(() => setToast(null), 4500) }
  const content = (() => {
    if (view === 'login') return <Login go={setView} />
    if (view === 'reset') return <ResetPassword go={setView} toast={notify} />
    if (view === 'student') return <Student logout={() => setView('login')} notify={notify} />
    if (view === 'librarian') return <Librarian logout={() => setView('login')} notify={notify} />
    return <Admin logout={() => setView('login')} notify={notify} />
  })()
  return <LibraryContext.Provider value={{ db, update, current, selectUser }}><div className="min-h-screen overflow-x-hidden">{storageError && <p role="alert" className="bg-amber-100 p-3 text-sm text-amber-950">Almacenamiento local no disponible: los cambios solo durarán hasta cerrar o recargar esta página.</p>}{content}<DemoNav view={view} setView={setView} /><ToastMessage toast={toast} close={() => setToast(null)} /></div></LibraryContext.Provider>
}
